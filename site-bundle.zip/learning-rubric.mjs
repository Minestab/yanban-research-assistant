// Accept equivalent list formats without inventing, truncating or splitting facts.
export function normalizeKeyPoints(value,label='理解题'){
 let points=value;
 if(typeof points==='string'){
  try{const parsed=JSON.parse(points);if(Array.isArray(parsed))points=parsed;}catch(_){}
  if(typeof points==='string')points=points.split(/\r?\n/).map(s=>s.replace(/^\s*(?:[-*•]\s+|\d+[、)）]\s*|\d+\.\s+)/,'').trim()).filter(Boolean);
 }
 if(!Array.isArray(points)||points.length<2||points.length>12)throw Error(label+'的自查要点不完整：需要 2–12 条文字要点。');
 if(points.some(p=>typeof p!=='string'||!p.trim()||p.length>600))throw Error(label+'的自查要点中存在空白、非文字或过长内容。');
 return points.map(p=>p.trim());
}
