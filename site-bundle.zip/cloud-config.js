// Public client configuration only. Never put service_role or database passwords here.
window.YANBAN_CLOUD_CONFIG = {url:'https://wogbntqfvpfjadbyzdvl.supabase.co',publishableKey:'sb_publishable_1H9H78VKnVXFWqwpYrGfJQ_FnjjRdyN'};
