import * as pdfjs from './vendor/pdfjs/build/pdf.mjs';
import {answer,translate,readingCard} from './research.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdfjs/build/pdf.worker.mjs',import.meta.url).href;
const realFetch=window.fetch.bind(window), jobs=new Map(), urls=new Map();
const metadataKey='yanban-public-model-v1';
let settings={provider:'deepseek',base_url:'https://api.deepseek.com',model:'deepseek-flash',api_key:''};
try{const old=JSON.parse(localStorage.getItem(metadataKey)||'{}');if(typeof old.model==='string')settings.model=old.model;}catch(_){}
const publicSettings=()=>({provider:settings.provider,base_url:settings.base_url,model:settings.model,has_api_key:!!settings.api_key,key_storage:settings.api_key?'session':'none'});
const database=new Promise((resolve,reject)=>{const req=indexedDB.open('yanban-public-papers-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('papers',{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(Error('浏览器未允许本地论文存储，请检查隐私设置。'));});
async function db(method,arg){const databaseConnection=await database;return new Promise((resolve,reject)=>{const tx=databaseConnection.transaction('papers',method==='put'?'readwrite':'readonly'),store=tx.objectStore('papers'),request=arg===undefined?store[method]():store[method](arg);tx.oncomplete=()=>resolve(request.result);tx.onerror=()=>reject(Error('论文保存失败，浏览器存储空间可能不足。'));tx.onabort=()=>reject(Error('论文保存未完成。'));});}
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});}
async function documentFor(id){const record=await db('get',id);if(!record)throw Error('当前浏览器中找不到这篇论文，请重新导入。');return record.document;}
function pdfURL(record){if(!urls.has(record.id))urls.set(record.id,URL.createObjectURL(record.blob));return urls.get(record.id);}
function gateway(signal){
 const config={...settings};
 return async(messages,options={})=>{
  if(!config.api_key)throw Error('请在模型设置中填写你自己的 DeepSeek API Key。');
  if(signal?.aborted)throw Error('请求已取消。');
  let response;
  try{response=await realFetch('https://api.deepseek.com/chat/completions',{method:'POST',credentials:'omit',referrerPolicy:'no-referrer',headers:{'Content-Type':'application/json',Authorization:'Bearer '+config.api_key},body:JSON.stringify({model:config.model,messages,temperature:0.2,max_tokens:options.max_tokens||2500,stream:false,thinking:{type:'disabled'},...(options.tools?{tools:options.tools,tool_choice:'auto'}:{})}),signal:signal?AbortSignal.any([signal,AbortSignal.timeout(120000)]):AbortSignal.timeout(120000)});}catch(error){throw Error(error.name==='TimeoutError'?'模型响应超时，请稍后重试。':'无法连接 DeepSeek，请检查网络或浏览器跨域限制。');}
  if(!response.ok)throw Error(response.status===401||response.status===403?'DeepSeek 拒绝了认证，请检查自己的 API Key。':response.status===429?'DeepSeek 限流或额度不足，请查看账户余额。':'DeepSeek 请求失败（'+response.status+'），请检查型号或稍后重试。');
  const data=await response.json(),choice=data.choices?.[0];
  if(choice?.finish_reason==='length')throw Error('模型输出超过长度上限，请缩小问题后重试。');
  if(!choice?.message||typeof choice.message!=='object')throw Error('模型返回的结果无法识别。');
  const message={role:'assistant',content:typeof choice.message.content==='string'?choice.message.content:''};
  if(Array.isArray(choice.message.tool_calls))message.tool_calls=choice.message.tool_calls;
  return {message,model:data.model||config.model,usage:data.usage||{}};
 };
}
async function parsePDF(file,job){
 let task;
 try{
  if(!(file instanceof Blob)||!file.size||file.size>20*1024*1024)throw Error('请选择 20 MB 以内的 PDF。');
  const buffer=await file.arrayBuffer();if(new TextDecoder().decode(buffer.slice(0,5))!=='%PDF-')throw Error('文件内容不是有效 PDF。');
  task=pdfjs.getDocument({data:new Uint8Array(buffer),isEvalSupported:false,cMapUrl:new URL('./vendor/pdfjs/cmaps/',import.meta.url).href,cMapPacked:true,standardFontDataUrl:new URL('./vendor/pdfjs/standard_fonts/',import.meta.url).href,wasmUrl:new URL('./vendor/pdfjs/wasm/',import.meta.url).href});
  task.onPassword=()=>{task.destroy();job.state='error';job.error='请先移除 PDF 密码保护后重新导入。';};
  const pdf=await task.promise;if(pdf.numPages>100)throw Error('第一版最多支持 100 页。');
  const paragraphs=[],emptyPages=[];let extractedChars=0;
  for(let number=1;number<=pdf.numPages;number++){
   job.message=`正在浏览器内提取第 ${number}/${pdf.numPages} 页文字…`;
   const page=await pdf.getPage(number),content=await page.getTextContent();
   let line='',block='',previousY=null;
   const flush=()=>{if(block.trim()){extractedChars+=block.trim().length;if(extractedChars>1000000)throw Error('PDF 提取文字过多，请拆分后导入。');paragraphs.push({id:'p'+(paragraphs.length+1),page:number,text:block.trim(),kind:'text'});}block='';};
   const addLine=()=>{if(line.trim()){if(block.length+line.length>1600)flush();block+=line.trim()+'\n';line='';}};
   const before=paragraphs.length;
   for(const item of content.items){if(typeof item.str!=='string')continue;const y=item.transform?.[5];if(previousY!==null&&y!==undefined&&Math.abs(previousY-y)>3){addLine();if(Math.abs(previousY-y)>22)flush();}line+=item.str+' ';previousY=y;if(item.hasEOL)addLine();}
   addLine();flush();if(before===paragraphs.length)emptyPages.push(number);page.cleanup();
   await new Promise(r=>setTimeout(r,0));
  }
  if(!paragraphs.length)throw Error('没有提取到文字，可能是扫描件。公开版尚不支持 OCR，请使用本地版。');
  let metadata;try{metadata=await pdf.getMetadata();}catch(_){}
  const id=crypto.randomUUID(),title=typeof metadata?.info?.Title==='string'&&metadata.info.Title.trim()?metadata.info.Title.trim():file.name.replace(/\.pdf$/i,'');
  const document={id,title,filename:file.name,page_count:pdf.numPages,created_at:new Date().toISOString(),parser:'PDF.js 浏览器基础文本提取',warnings:['公开版按 PDF 文字层提取，不等同于 Docling 版面解析；多栏阅读顺序、图表与公式请对照原 PDF。',...(emptyPages.length?['没有提取到文字的页面：'+emptyPages.join('、')]:[])],paragraphs};
  await db('put',{id,document,blob:file});job.state='ready';job.document_id=id;job.message='解析完成，论文仅保存在当前浏览器。';
 }catch(error){job.state='error';job.error=job.error||error.message;job.message=job.error;}
 finally{if(task)await task.destroy().catch(()=>{});}
}
window.fetch=async(input,options={})=>{
 const url=new URL(typeof input==='string'?input:input.url,location.href);
 if(url.origin!==location.origin||!url.pathname.startsWith('/api/'))return realFetch(input,options);
 const path=url.pathname,method=(options.method||'GET').toUpperCase();
 try{
  const body=typeof options.body==='string'?JSON.parse(options.body):options.body;
  if(path==='/api/status')return json({service:'yanban',version:'public-0.3',configured:!!settings.api_key,provider:settings.provider,model:settings.model,base_url:settings.base_url,csrf_token:'browser-only',parser:{available:true,default_engine:'pdfjs'},storage:'browser'});
  if(path==='/api/config'){
   if(method==='POST'){
    if(body.provider!=='deepseek'||body.base_url!=='https://api.deepseek.com')throw Error('公开版只连接 DeepSeek 官方接口。');
    if(typeof body.model!=='string'||!body.model.trim()||body.model.length>180||/[\x00-\x1f]/.test(body.model))throw Error('模型编号无效。');
    const supplied=String(body.api_key||'').trim();if(supplied.length>4096||/[\s\x00-\x1f]/.test(supplied))throw Error('API Key 格式不正确。');
    settings={provider:'deepseek',base_url:'https://api.deepseek.com',model:body.model.trim(),api_key:body.clear_key?'':supplied||settings.api_key};
    try{localStorage.setItem(metadataKey,JSON.stringify({model:settings.model}));}catch(_){}
   }return json(publicSettings());
  }
  if(path==='/api/config/test'){const result=await gateway(options.signal)([{role:'user',content:'只回复 OK'}],{max_tokens:16});return json({ok:true,model:result.model,message:'已通过你的浏览器连接 DeepSeek。'});}
  if(path==='/api/documents'&&method==='GET'){const records=await db('getAll');return json({documents:records.map(({document:d})=>({id:d.id,title:d.title,filename:d.filename,page_count:d.page_count,paragraph_count:d.paragraphs.length,created_at:d.created_at,parser:d.parser,warnings:d.warnings})).sort((a,b)=>b.created_at.localeCompare(a.created_at))});}
  if(path==='/api/documents'&&method==='POST'){const id=crypto.randomUUID(),job={id,state:'parsing',message:'正在浏览器中检查 PDF…'};jobs.set(id,job);parsePDF(body.get('file'),job);return json({job_id:id});}
  if(path.startsWith('/api/jobs/')){const job=jobs.get(path.split('/').pop());if(!job)throw Error('解析任务已失效，请重新导入。');return json(job);}
  if(path.startsWith('/api/documents/')){const id=path.split('/')[3],record=await db('get',id);if(!record)throw Error('当前浏览器中找不到该论文。');return path.endsWith('/file')?new Response(record.blob,{headers:{'Content-Type':'application/pdf'}}):json({...record.document,file_url:pdfURL(record)});}
  if(['/api/chat','/api/translate','/api/reading-card'].includes(path)){
   const doc=await documentFor(body.document_id),complete=gateway(options.signal);
   if(path==='/api/chat')return json(await answer(doc,body.question,body.history||[],body.selected_paragraph_ids||[],complete));
   if(path==='/api/translate')return json(await translate(doc,body.paragraph_ids,complete));
   return json(await readingCard(doc,complete));
  }
  return json({detail:{code:'not_found',message:'功能接口不存在。'}},404);
 }catch(error){return json({detail:{code:'public_error',message:error instanceof SyntaxError?'模型或请求返回了无效 JSON，请重试。':error.message}},400);}
};
window.YANBAN_PUBLIC=true;
await import('./app.js');

document.querySelector("#forget-public-key").addEventListener("click",()=>{settings.api_key="";document.querySelector("#model-key").value="";document.querySelector("[data-action=refresh-connection]").click();});
